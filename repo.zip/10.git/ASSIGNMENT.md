This is a placeholder file to initalize the git repository.
See the real assignment handout file for instructions
